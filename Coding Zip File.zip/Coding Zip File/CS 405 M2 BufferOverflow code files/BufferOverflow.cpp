// BufferOverflow.cpp
// CS 405 – Module Two: Buffer Overflow Activity
//
// Edited by: Karina Washington
// Date: January 9th, 2026
//
// Purpose:
// This program demonstrates how to safely handle user input in C++ in order
// to prevent buffer overflow vulnerabilities. The code ensures that user input
// cannot overwrite adjacent memory, including sensitive variables such as
// account numbers, and notifies the user if excessive input is detected.
//

#include <iomanip>
#include <iostream>
#include <limits>   // Used for clearing the input stream safely
#include <string>   // Used for std::string account_number

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // IMPORTANT SECURITY NOTE:
    // Per the assignment requirements, the account_number variable:
    // 1. Must remain unchanged
    // 2. Must remain directly before the variable used for user input
    // 3. Must not be affected by user input under any circumstances
    //
    // This simulates protecting sensitive data (such as account numbers)
    // from accidental or malicious buffer overflow attacks.

    const std::string account_number = "CharlieBrown42";

    // Fixed-size character buffer for user input.
    // Size is intentionally limited to demonstrate overflow protection.
    // This buffer can safely store up to 19 characters plus a null terminator.
    char user_input[20];

    std::cout << "Enter a value: ";

    // SECURE INPUT HANDLING:
    // std::cin.get() reads at most (sizeof(user_input) - 1) characters
    // and automatically appends a null terminator.
    //
    // This prevents writing beyond the bounds of the buffer and
    // completely eliminates the possibility of a buffer overflow.
    std::cin.get(user_input, sizeof(user_input));

    // Flag used to indicate whether the user attempted to enter
    // more data than the buffer allows.
    bool overflow_attempt = false;

    // BUFFER OVERFLOW DETECTION:
    // If the buffer filled up before encountering a newline character,
    // then additional characters are still waiting in the input stream.
    // This indicates an attempted buffer overflow.
    if (std::cin.peek() != '\n' && !std::cin.eof())
    {
        overflow_attempt = true;

        // INPUT STREAM CLEANUP:
        // Clear all remaining characters up to the newline.
        // This prevents leftover input from affecting future reads.
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    else
    {
        // If a newline is present, consume it so the input stream
        // remains in a clean and predictable state.
        if (std::cin.peek() == '\n')
        {
            std::cin.get();
        }
    }

    // DISPLAY USER INPUT
    std::cout << "You entered: " << user_input << std::endl;

    // USER NOTIFICATION:
    // Inform the user when their input exceeded the buffer size
    // and had to be truncated to prevent a buffer overflow.
    if (overflow_attempt)
    {
        std::cout << "WARNING: Input exceeded the maximum allowed length and was "
                  << "truncated to prevent a buffer overflow." << std::endl;
    }

    // DISPLAY PROTECTED DATA:
    // This output demonstrates that the account number was NOT modified,
    // proving that the buffer overflow prevention was successful.
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu