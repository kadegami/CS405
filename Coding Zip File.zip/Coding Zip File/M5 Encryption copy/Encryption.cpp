// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Edited by: Karina Washington
// Date: 2026-01-23
// Purpose: Demonstrate XOR-based file encryption/decryption, plus loading/saving
//          data files in the required format for CS 405 Module Five Encryption Activity.
//

#include <cassert>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

/// <summary>
/// Encrypt or decrypt a source string using XOR with the provided key.
/// XOR is symmetric: encrypt_decrypt(encrypt_decrypt(text, key), key) == text.
/// </summary>
/// <param name="source">Input string to process</param>
/// <param name="key">Key to use in encryption / decryption (must not be empty)</param>
/// <returns>Transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
  // Cache lengths so we don't keep calling .length() inside the loop.
  const auto key_length = key.length();
  const auto source_length = source.length();

  // Validate inputs (rubric cares that we handle key length correctly).
  if (key_length == 0)
  {
    throw std::invalid_argument("Encryption key must not be empty.");
  }
  if (source_length == 0)
  {
    // Nothing to transform; return empty string (safe behavior).
    return {};
  }

  // Start output as a copy of source; we'll mutate each character.
  std::string output = source;

  // XOR each byte with a key byte (wrap key using modulo).
  // NOTE: Use unsigned char to avoid sign-extension surprises on some platforms.
  for (size_t i = 0; i < source_length; ++i)
  {
    const unsigned char s = static_cast<unsigned char>(source[i]);
    const unsigned char k = static_cast<unsigned char>(key[i % key_length]);
    output[i] = static_cast<char>(s ^ k);
  }

  // Sanity check: output size should match input size.
  assert(output.length() == source_length);
  return output;
}

/// <summary>
/// Load the entire contents of a text file into a single std::string.
/// The input file format is described in main(). We do not parse the content here;
/// we read it exactly as-is so encryption/decryption round-trips cleanly.
/// </summary>
std::string read_file(const std::string& filename)
{
  std::ifstream in(filename, std::ios::in | std::ios::binary);
  if (!in)
  {
    // The original template checks for "ERROR", so keep that behavior.
    return "ERROR";
  }

  std::ostringstream buffer;
  buffer << in.rdbuf();

  const std::string file_text = buffer.str();
  if (file_text.empty())
  {
    // Empty files are not useful for the activity; treat as error.
    return "ERROR";
  }

  return file_text;
}

/// <summary>
/// Extract the student's name from the first line of the loaded file.
/// </summary>
std::string get_student_name(const std::string& string_data)
{
  std::string student_name;

  // Find the first newline.
  const size_t pos = string_data.find('\n');

  // If we found a newline, copy that substring as the student name.
  // Otherwise, treat the entire string as "line 1".
  if (pos != std::string::npos)
  {
    student_name = string_data.substr(0, pos);
  }
  else
  {
    student_name = string_data;
  }

  return student_name;
}

/// <summary>
/// Save a data file using the required format:
/// Line 1: student name
/// Line 2: timestamp (yyyy-mm-dd)
/// Line 3: key used
/// Line 4+: data (the encrypted or decrypted payload)
/// </summary>
void save_data_file(const std::string& filename,
                    const std::string& student_name,
                    const std::string& key,
                    const std::string& data)
{
  std::ofstream out(filename, std::ios::out | std::ios::binary | std::ios::trunc);
  if (!out)
  {
    // Fail loudly—writing files is a core requirement of this activity.
    throw std::runtime_error("Failed to open output file for writing: " + filename);
  }

  // Build timestamp string in yyyy-mm-dd format (local time).
  const std::time_t now = std::time(nullptr);
  std::tm local_tm{};
#if defined(_WIN32)
  localtime_s(&local_tm, &now);
#else
  local_tm = *std::localtime(&now);
#endif

  std::ostringstream date_ss;
  date_ss << std::put_time(&local_tm, "%Y-%m-%d");

  // Write required header lines.
  out << student_name << "\n";
  out << date_ss.str() << "\n";
  out << key << "\n";

  // IMPORTANT: Write the data exactly as provided.
  // Do NOT add formatting that would prevent decryption round-tripping.
  out << data;

  out.close();
  if (!out)
  {
    throw std::runtime_error("Failed while writing output file: " + filename);
  }
}

int main()
{
  std::cout << "Encyption Decryption Test!" << std::endl;

  // Input file format (must match what you create in inputdatafile.txt)
  // Line 1: <student's name>
  // Line 2: <Lorem Ipsum Generator website used>
  // Lines 3+: <3 paragraphs of generated text>
  //
  // NOTE: Your submission ZIP must include:
  //  - inputdatafile.txt (your original data file)
  //  - encrypteddatafile.txt (generated by this program)
  //  - decrytpteddatafile.txt (generated by this program; filename is intentionally misspelled in the template)
  //  - Encryption.cpp (this source file)

  const std::string file_name = "inputdatafile.txt";
  const std::string encrypted_file_name = "encrypteddatafile.txt";
  const std::string decrypted_file_name = "decrytpteddatafile.txt";

  // Read the original file (returns "ERROR" if it cannot be read).
  const std::string source_string = read_file(file_name);
  if (source_string == "ERROR")
  {
    std::cout << "ERROR: Could not read input file: " << file_name << std::endl;
    return 1;
  }

  // Key used for XOR encryption (must be non-empty).
  const std::string key = "password";

  // Get the student's name from line 1.
  const std::string student_name = get_student_name(source_string);

  try
  {
    // Encrypt source_string with key.
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // Save encrypted string to file.
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt encrypted string with key (XOR reverses itself).
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // Save decrypted string to file.
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);
  }
  catch (const std::exception& ex)
  {
    // Catch-all for standard exceptions (safe error handling).
    std::cout << "ERROR: " << ex.what() << std::endl;
    return 1;
  }

  std::cout << "Read File: " << file_name
            << " - Encrypted To: " << encrypted_file_name
            << " - Decrypted To: " << decrypted_file_name << std::endl;

  // Students submit: input file, encrypted file, decrypted file, source code file, and key used.
  return 0;
}
