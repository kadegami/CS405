// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Edited by Karina Washington
// Date: 2026-01-09
//
// Purpose:
// - Demonstrate standard + custom exceptions
// - Catch std::exception
// - Catch-all handler
// - Display exception messages using what()

#include <iostream>
#include <stdexcept>   // std::runtime_error, std::invalid_argument
#include <exception>   // std::exception

// Custom exception derived from std::exception (requirement)
class CustomAppException : public std::runtime_error
{
public:
  explicit CustomAppException(const std::string& message)
    : std::runtime_error(message) {}
};

bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception
  // Using a standard exception derived from std::exception (good practice)
  std::cout << "Running Even More Custom Application Logic." << std::endl;

  throw std::runtime_error("Standard exception from do_even_more_custom_application_logic()");

  // return true; // unreachable, left here to show intent of original function
}

void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  // with an exception handler that catches std::exception, displays
  // a message and the exception.what(), then continues processing
  std::cout << "Running Custom Application Logic." << std::endl;

  try
  {
    if (do_even_more_custom_application_logic())
    {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  catch (const std::exception& ex)
  {
    // Requirement: display message + ex.what(), then continue processing
    std::cout << "Handled std::exception inside do_custom_application_logic(): " << ex.what() << std::endl;
  }

  // TODO: Throw a custom exception derived from std::exception
  // and catch it explicitly in main
  throw CustomAppException("CustomAppException thrown from do_custom_application_logic()");

  // std::cout << "Leaving Custom Application Logic." << std::endl; // unreachable after throw
}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  // a standard C++ defined exception
  if (den == 0.0f)
  {
    throw std::invalid_argument("Divide by zero error in divide()");
  }

  return (num / den);
}

void do_division() noexcept
{
  // TODO: create an exception handler to capture ONLY the exception thrown by divide.
  // Note: this function is marked noexcept, so we must catch any exception here.
  float numerator = 10.0f;
  float denominator = 0.0f;

  try
  {
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::invalid_argument& ex)
  {
    // Catch ONLY the exception type we threw from divide()
    std::cout << "Handled divide() exception: " << ex.what() << std::endl;
  }
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // TODO: Create exception handlers that catch (in this order):
  //  your custom exception
  //  std::exception
  //  uncaught exception (catch-all)
  // that wraps the whole main function, and displays a message to the console.
  try
  {
    do_division();
    do_custom_application_logic();
  }
  catch (const CustomAppException& ex)
  {
    std::cout << "Handled CustomAppException in main(): " << ex.what() << std::endl;
  }
  catch (const std::exception& ex)
  {
    std::cout << "Handled std::exception in main(): " << ex.what() << std::endl;
  }
  catch (...)
  {
    std::cout << "Handled unknown/unexpected exception in main()." << std::endl;
  }

  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu