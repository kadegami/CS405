// Milestone 4 Unit Testing
// Edited by: Karina Washington
// Date: January 28, 2026
//
// Purpose:
// This file contains Google Test (gtest) unit tests for std::vector<int> using a test fixture.
// It includes both positive tests (expected behavior) and negative tests (expected exceptions).
//
// Notes for Instructor / Reviewer:
// - ASSERT_* is used when the test cannot continue if the condition fails (critical preconditions).
// - EXPECT_* is used when we want to record failures but continue evaluating the test.

#include <stdexcept>     // std::out_of_range
#include "pch.h"         // Precompiled header for Visual Studio projects (required by template)
#include <gtest/gtest.h> // Google Test framework
#include <vector>        // std::vector
#include <memory>        // std::unique_ptr, std::make_unique
#include <cassert>       // assert (used in helper to enforce valid input)
#include <cstdlib>       // rand, srand
#include <ctime>         // time

// ---------------------------------------------------------
// Global test environment
// ---------------------------------------------------------
// This runs once for the entire test program (before any tests start).
// We seed the random generator a single time so tests that rely on rand()
// produce varied values across runs (while still being within expected ranges).
class Environment : public ::testing::Environment
{
public:
    void SetUp() override
    {
        // Initialize random seed once for all tests
        srand(static_cast<unsigned int>(time(nullptr)));
    }
};

// ---------------------------------------------------------
// Test Fixture: shared setup for all vector tests
// ---------------------------------------------------------
// A fixture provides a fresh vector for each test to ensure tests are isolated.
// Isolation prevents "test order" bugs where one test affects another.
class CollectionTest : public ::testing::Test
{
protected:
    // Using a smart pointer demonstrates modern C++ ownership and automatic cleanup.
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        // Create a new vector before each test (ensures a clean starting state)
        collection = std::make_unique<std::vector<int>>();
    }

    void TearDown() override
    {
        // Clean up after each test (good hygiene, though unique_ptr would handle this)
        collection->clear();
        collection.reset();
    }

    // Helper function to add random values (0–99) to the collection
    // Defensive check: count must be positive to avoid invalid calls.
    void add_entries(int count)
    {
        assert(count > 0); // In debug builds, fail fast if caller passes invalid count
        for (int i = 0; i < count; ++i)
        {
            // rand()%100 constrains values into a known safe range for validation tests
            collection->push_back(rand() % 100);
        }
    }
};

// ---------------------------------------------------------
// Required tests (positive and negative)
// ---------------------------------------------------------

// Positive test: adding a single value should change size from 0 to 1.
TEST_F(CollectionTest, CanAddSingleValueToEmptyVector)
{
    // Preconditions: if these fail, the rest of the test does not make sense
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);

    add_entries(1);

    // Postconditions: the collection should contain exactly 1 element
    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1u);
}

// Positive test: adding five values should result in size 5.
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);
    EXPECT_EQ(collection->size(), 5u);
}

// Positive test: max_size() is a theoretical upper bound and must be >= current size.
// We repeat this at multiple sizes to prove the condition holds after growth.
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize)
{
    // 0 entries
    EXPECT_GE(collection->max_size(), collection->size());

    // 1 entry
    add_entries(1);
    EXPECT_GE(collection->max_size(), collection->size());

    // 5 entries
    collection->clear();
    add_entries(5);
    EXPECT_GE(collection->max_size(), collection->size());

    // 10 entries
    collection->clear();
    add_entries(10);
    EXPECT_GE(collection->max_size(), collection->size());
}

// Positive test: capacity() should always be >= size().
// This verifies vector’s internal storage is not smaller than the number of elements.
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize)
{
    // 0 entries
    EXPECT_GE(collection->capacity(), collection->size());

    // 1 entry
    add_entries(1);
    EXPECT_GE(collection->capacity(), collection->size());

    // 5 entries
    collection->clear();
    add_entries(5);
    EXPECT_GE(collection->capacity(), collection->size());

    // 10 entries
    collection->clear();
    add_entries(10);
    EXPECT_GE(collection->capacity(), collection->size());
}

// Positive test: resize() to a larger size should increase size accordingly.
TEST_F(CollectionTest, ResizeIncreasesSize)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u); // ASSERT: must start at 5 for the test to be meaningful

    collection->resize(10);

    EXPECT_EQ(collection->size(), 10u);
}

// Positive test: resize() to a smaller size should decrease size accordingly.
TEST_F(CollectionTest, ResizeDecreasesSize)
{
    add_entries(10);
    ASSERT_EQ(collection->size(), 10u);

    collection->resize(5);

    EXPECT_EQ(collection->size(), 5u);
}

// Positive test: resizing to zero should behave like clearing (empty collection).
TEST_F(CollectionTest, ResizeToZeroClearsCollection)
{
    add_entries(5);
    ASSERT_FALSE(collection->empty()); // Ensure we had data before shrinking to 0

    collection->resize(0);

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0u);
}

// Positive test: clear() should remove all elements.
TEST_F(CollectionTest, ClearEmptiesCollection)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u);

    collection->clear();

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0u);
}

// Positive test: erase(begin,end) should remove all elements (equivalent to clear()).
TEST_F(CollectionTest, EraseBeginEndClearsCollection)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u);

    collection->erase(collection->begin(), collection->end());

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0u);
}

// Positive test: reserve() should increase capacity (or keep it >= requested),
// but should NOT change size (number of actual stored elements).
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    add_entries(5);
    size_t oldSize = collection->size();
    size_t oldCap = collection->capacity();

    collection->reserve(oldCap + 50);

    EXPECT_EQ(collection->size(), oldSize);              // size unchanged
    EXPECT_GE(collection->capacity(), oldCap + 50);      // capacity increased to at least requested
}

// Negative test: vector::at() must throw std::out_of_range when index is invalid.
// This demonstrates safe bounds checking behavior.
TEST_F(CollectionTest, AtThrowsOutOfRange)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u);

    // Index 10 is out of bounds when size is 5 (valid indices: 0..4)
    EXPECT_THROW(collection->at(10), std::out_of_range);
}

// ---------------------------------------------------------
// Custom tests (1 positive + 1 negative as required)
// ---------------------------------------------------------

// Positive custom test: values added are constrained to 0–99 by rand()%100.
TEST_F(CollectionTest, ValuesWithinExpectedRange)
{
    add_entries(10);
    ASSERT_EQ(collection->size(), 10u);

    for (int v : *collection)
    {
        EXPECT_GE(v, 0);
        EXPECT_LE(v, 99);
    }
}

// Negative custom test: at() should throw for a clearly invalid large index.
TEST_F(CollectionTest, AtThrowsOutOfRangeForLargeIndex)
{
    add_entries(1);
    ASSERT_EQ(collection->size(), 1u);

    EXPECT_THROW(collection->at(1000), std::out_of_range);
}

// ---------------------------------------------------------
// Test Runner (main)
// ---------------------------------------------------------
// This main() is required when you are NOT using the gtest_main library.
// It initializes Google Test, registers the global environment, and runs all tests.
int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);

    // Register global environment (runs once before all tests)
    ::testing::AddGlobalTestEnvironment(new Environment());

    // Run the full suite and return gtest's status code
    return RUN_ALL_TESTS();
}